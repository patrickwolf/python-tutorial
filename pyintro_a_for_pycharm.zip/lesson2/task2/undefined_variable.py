variable = 1
print(other variable)