two = 2
three = 3

is_equal = two operator three

print(is_equal)