# TODO: type solution here
'''
@summary: Python Intro - Basic DataTypes
'''
# ----------------------
# Assignments
# ----------------------
# first assignment creates name which references value in memory, types are inferred
aint = 5
print type(aint)
aint = "test"
print type(aint)

# ---------------------------
# Numbers
# ---------------------------
a = 5 + 5  # int
b = 2.5  # float

# ---------------------------
# Boolean
# ---------------------------
a = True
b = False


