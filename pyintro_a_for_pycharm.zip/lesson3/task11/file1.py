
# ---------------------------
# Strings
# ---------------------------
# usage of " and '
st = "abc"
st = 'abc'
st = "ab'c'd"

# multi line
val = """
'line1' <- can contain '
"line2" <- and "
"""

# ----------------------
# operator + - concatenation
# ----------------------
print 5 + 10.2  # 15.2
print "abc" + "def"  # abcdef

# ---------------------------
# operator * - repeat
# ---------------------------
print "abc,"*5  # abc,abc,abc,abc,abc,
print (5,3,2)*2 # (5, 3, 2, 5, 3, 2)

# ---------------------------
# raw strings (no need to escape)
# ---------------------------
print "c:\\test\\abc"  # c:\test\abc
print r"c:\test\abc"  # c:\test\abc

# ---------------------------
# string formating
# ---------------------------
print "part1 '%s' part2 '%s'" % ('a', 'b')

print "part1 '%s' " % 'b'

# ---------------------------
# slicing or accessing members via "array" notation
# ---------------------------
# variable[X]          - item X
# variable[fromX:toY]
# variable[fromX:-toY] - "-toY" starting from last
# variable[:toY]       - from first
# variable[fromX:]     - to last
# variable[:]          - all items

st = "abcdefghijklmnop"
print st[:], st[:2], st[2:], st[1], st[2:3], st[-1] # abcdefghijklmnop ab cdefghijklmnop b c p

# slicing always returns a copy
print id(st), id(st[:])