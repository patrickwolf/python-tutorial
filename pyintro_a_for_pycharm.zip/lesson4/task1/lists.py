squares = [1, 4, 9, 16, 25]   # create new list
print(squares)

print(slice)