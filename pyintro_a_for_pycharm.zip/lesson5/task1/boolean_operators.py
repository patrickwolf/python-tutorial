name = "John"
age = 17

print(name == "John" or age == 17)    # checks that either name equals to "John" OR age equals to 17

print(John is not 23 years old)