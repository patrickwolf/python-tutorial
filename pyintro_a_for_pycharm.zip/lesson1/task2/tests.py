from test_helper import run_common_tests

if __name__ == '__main__':
    run_common_tests("You should type new comment")
