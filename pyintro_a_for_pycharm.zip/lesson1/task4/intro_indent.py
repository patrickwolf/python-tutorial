
# ----------------------
# Indentation
# ----------------------

# python uses indentation instead of brackets (can be space or tab)
if True:
    pass
    if False:
        pass
    elif True:
        pass
    else:
        pass

# you can write code after the :
if True: print "one liner also works"