def foo(x):                 # x is a function parameter
    print("x = " + str(x))

foo(5)   # pass 5 to foo(). Here 5 is an argument passed to function foo.

define a function named 'square' that prints square of passed parameter
    print(x ** 2)

square(4)
square(8)
square(15)
square(23)
square(42)